import React from 'react';
import { motion } from 'framer-motion';
import { Truck, MousePointerClick, Globe2 } from 'lucide-react';
import { Card } from './ui/Card';
export function Solution() {
  const features = [
  {
    icon: <Truck className="w-8 h-8 text-basmo-green" />,
    title: 'Penjemputan dari Kos',
    description:
    'Tidak perlu repot keluar. Tim kami akan datang langsung ke depan pintu kos atau tempat tinggal Anda untuk mengambil sampah plastik.',
    delay: 0.1
  },
  {
    icon: <MousePointerClick className="w-8 h-8 text-basmo-green" />,
    title: 'Sistem Online Praktis',
    description:
    'Cukup isi form permintaan penjemputan melalui website dari smartphone Anda. Jadwal bisa disesuaikan dengan waktu luang Anda.',
    delay: 0.2
  },
  {
    icon: <Globe2 className="w-8 h-8 text-basmo-green" />,
    title: 'Dukung Keberlanjutan',
    description:
    'Setiap botol yang Anda serahkan ke BASMO akan disalurkan ke mitra daur ulang, mendukung program lingkungan berkelanjutan.',
    delay: 0.3
  }];

  return (
    <section className="py-20 bg-basmo-light/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.h2
            initial={{
              opacity: 0,
              y: 20
            }}
            whileInView={{
              opacity: 1,
              y: 0
            }}
            viewport={{
              once: true
            }}
            className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">

            Solusi dari BASMO
          </motion.h2>
          <motion.p
            initial={{
              opacity: 0,
              y: 20
            }}
            whileInView={{
              opacity: 1,
              y: 0
            }}
            viewport={{
              once: true
            }}
            transition={{
              delay: 0.1
            }}
            className="text-lg text-gray-600">

            BASMO menyediakan sistem layanan penjemputan sampah plastik yang
            memudahkan mahasiswa untuk mengelola sampah secara praktis melalui
            website.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) =>
          <Card
            key={index}
            delay={feature.delay}
            className="p-8 hover:-translate-y-2 transition-transform duration-300">

              <div className="w-16 h-16 rounded-2xl bg-basmo-light flex items-center justify-center mb-6">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </Card>
          )}
        </div>
      </div>
    </section>);

}