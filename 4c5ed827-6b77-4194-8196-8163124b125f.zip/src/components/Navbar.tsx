import React, { useEffect, useState } from 'react';
import { Leaf, Menu, X } from 'lucide-react';
import { Button } from './ui/Button';
export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  const navLinks = [
  {
    name: 'Home',
    href: '#home'
  },
  {
    name: 'Tentang',
    href: '#problem'
  },
  {
    name: 'Layanan',
    href: '#how-it-works'
  },
  {
    name: 'Kontak',
    href: '#pickup-form'
  }];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'}`}>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2 group">
            <div className="bg-basmo-green text-white p-2 rounded-xl group-hover:rotate-12 transition-transform">
              <Leaf className="w-6 h-6" />
            </div>
            <span className="font-bold text-xl tracking-tight text-basmo-dark">
              BASMO
            </span>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) =>
            <a
              key={link.name}
              href={link.href}
              className="text-gray-600 hover:text-basmo-green font-medium transition-colors">

                {link.name}
              </a>
            )}
          </nav>

          {/* Desktop CTA */}
          <div className="hidden md:block">
            <a href="#pickup-form">
              <Button variant="primary" size="sm">
                Jemput Sampah
              </Button>
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden text-gray-600 p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>

            {isMobileMenuOpen ?
            <X className="w-6 h-6" /> :

            <Menu className="w-6 h-6" />
            }
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {isMobileMenuOpen &&
      <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-lg border-t border-gray-100 py-4 px-4 flex flex-col gap-4">
          {navLinks.map((link) =>
        <a
          key={link.name}
          href={link.href}
          className="text-gray-600 hover:text-basmo-green font-medium py-2 px-4 rounded-lg hover:bg-basmo-light transition-colors"
          onClick={() => setIsMobileMenuOpen(false)}>

              {link.name}
            </a>
        )}
          <a href="#pickup-form" onClick={() => setIsMobileMenuOpen(false)}>
            <Button variant="primary" className="w-full mt-2">
              Jemput Sampah
            </Button>
          </a>
        </div>
      }
    </header>);

}