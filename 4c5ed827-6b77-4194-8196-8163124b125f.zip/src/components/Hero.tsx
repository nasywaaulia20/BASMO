import React from 'react';
import { motion } from 'framer-motion';
import { Recycle, Smartphone, Leaf } from 'lucide-react';
import { Button } from './ui/Button';
export function Hero() {
  return (
    <section
      id="home"
      className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden bg-gradient-to-br from-basmo-light via-white to-basmo-pink/30">

      {/* Decorative background elements */}
      <div className="absolute top-20 left-10 text-basmo-green/20 animate-pulse">
        <Leaf className="w-12 h-12" />
      </div>
      <div className="absolute bottom-20 right-10 text-basmo-green/20 animate-pulse delay-700">
        <Recycle className="w-16 h-16" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <motion.div
            initial={{
              opacity: 0,
              x: -30
            }}
            animate={{
              opacity: 1,
              x: 0
            }}
            transition={{
              duration: 0.6
            }}
            className="text-center lg:text-left">

            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white shadow-sm border border-emerald-100 text-basmo-green font-medium text-sm mb-6">
              <Leaf className="w-4 h-4" />
              <span>Layanan Penjemputan Sampah Mahasiswa</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              BASMO <br />
              <span className="text-basmo-green">Bank Sampah Mobile</span>
            </h1>

            <p className="text-xl text-gray-700 font-medium mb-4">
              Cara mudah bagi mahasiswa untuk mendaur ulang sampah plastik.
            </p>

            <p className="text-gray-600 mb-8 max-w-lg mx-auto lg:mx-0 leading-relaxed">
              BASMO membantu mahasiswa mengelola sampah plastik dengan
              menyediakan layanan penjemputan langsung dari kos atau tempat
              tinggal. Bebas repot, dukung lingkungan bersih.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <a href="#pickup-form">
                <Button
                  variant="primary"
                  size="lg"
                  className="w-full sm:w-auto">

                  Jadwalkan Penjemputan Sampah
                </Button>
              </a>
              <a href="#how-it-works">
                <Button
                  variant="secondary"
                  size="lg"
                  className="w-full sm:w-auto">

                  Pelajari Cara Kerja
                </Button>
              </a>
            </div>
          </motion.div>

          {/* Illustration */}
          <motion.div
            initial={{
              opacity: 0,
              x: 30
            }}
            animate={{
              opacity: 1,
              x: 0
            }}
            transition={{
              duration: 0.6,
              delay: 0.2
            }}
            className="relative">

            <div className="relative w-full max-w-md mx-auto aspect-square">
              {/* Abstract shapes for illustration background */}
              <div className="absolute inset-0 bg-basmo-green/10 rounded-full blur-3xl"></div>

              {/* Main illustration composition */}
              <div className="relative h-full w-full flex items-center justify-center">
                <div className="relative bg-white p-8 rounded-3xl shadow-xl border border-emerald-50 z-20">
                  <Smartphone
                    className="w-32 h-32 text-gray-800 mx-auto mb-4"
                    strokeWidth={1.5} />

                  <div className="absolute -right-4 -top-4 bg-basmo-light p-4 rounded-full shadow-lg animate-bounce">
                    <Recycle className="w-8 h-8 text-basmo-green" />
                  </div>
                  <div className="absolute -left-6 bottom-10 bg-basmo-pink p-3 rounded-full shadow-lg">
                    <Leaf className="w-6 h-6 text-pink-500" />
                  </div>
                  <div className="text-center">
                    <div className="h-2 w-16 bg-gray-200 rounded-full mx-auto mb-2"></div>
                    <div className="h-2 w-24 bg-basmo-green/30 rounded-full mx-auto"></div>
                  </div>
                </div>

                {/* Floating elements */}
                <motion.div
                  animate={{
                    y: [0, -15, 0]
                  }}
                  transition={{
                    repeat: Infinity,
                    duration: 3,
                    ease: 'easeInOut'
                  }}
                  className="absolute top-10 right-10 bg-white p-3 rounded-2xl shadow-md">

                  <div className="w-6 h-12 border-2 border-blue-200 rounded-full relative overflow-hidden">
                    <div className="absolute bottom-0 left-0 right-0 h-3/4 bg-blue-100"></div>
                  </div>
                </motion.div>

                <motion.div
                  animate={{
                    y: [0, 15, 0]
                  }}
                  transition={{
                    repeat: Infinity,
                    duration: 4,
                    ease: 'easeInOut'
                  }}
                  className="absolute bottom-10 left-10 bg-white p-3 rounded-2xl shadow-md">

                  <div className="w-8 h-10 border-2 border-blue-200 rounded-lg relative overflow-hidden">
                    <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-blue-100"></div>
                  </div>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>);

}