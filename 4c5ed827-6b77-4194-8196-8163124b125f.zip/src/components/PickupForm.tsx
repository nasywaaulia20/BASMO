import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, CheckCircle2 } from 'lucide-react';
import { Card } from './ui/Card';
import { Button } from './ui/Button';
export function PickupForm() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitted(true);
    }, 800);
  };
  return (
    <section
      id="pickup-form"
      className="py-20 bg-basmo-dark text-white relative overflow-hidden">

      {/* Background Pattern */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: 'radial-gradient(#d1fae5 2px, transparent 2px)',
          backgroundSize: '30px 30px'
        }}>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <motion.div
            initial={{
              opacity: 0,
              x: -30
            }}
            whileInView={{
              opacity: 1,
              x: 0
            }}
            viewport={{
              once: true
            }}>

            <h2 className="text-3xl md:text-5xl font-bold mb-6 leading-tight">
              Ajukan Penjemputan Sampah Sekarang
            </h2>
            <p className="text-emerald-100 text-lg mb-8 max-w-md">
              Isi form di samping dan tim kami akan segera menghubungi Anda
              untuk mengatur jadwal penjemputan di kos Anda.
            </p>

            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="text-basmo-light w-6 h-6" />
                <span>Gratis biaya penjemputan</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="text-basmo-light w-6 h-6" />
                <span>Minimal 1 kantong besar botol/galon plastik</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="text-basmo-light w-6 h-6" />
                <span>
                  Dapatkan poin untuk setiap penjemputan (Coming Soon)
                </span>
              </div>
            </div>
          </motion.div>

          {/* Form Card */}
          <motion.div
            initial={{
              opacity: 0,
              y: 30
            }}
            whileInView={{
              opacity: 1,
              y: 0
            }}
            viewport={{
              once: true
            }}>

            <Card className="p-8 bg-white text-gray-800 shadow-2xl">
              {isSubmitted ?
              <div className="text-center py-12">
                  <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 className="w-10 h-10 text-basmo-green" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    Permintaan Terkirim!
                  </h3>
                  <p className="text-gray-600 mb-8">
                    Terima kasih. Admin kami akan segera menghubungi Anda
                    melalui WhatsApp untuk konfirmasi jadwal penjemputan.
                  </p>
                  <Button
                  onClick={() => setIsSubmitted(false)}
                  variant="outline"
                  className="w-full">

                    Ajukan Penjemputan Lain
                  </Button>
                </div> :

              <form onSubmit={handleSubmit} className="space-y-5">
                  <h3 className="text-2xl font-bold text-gray-900 mb-6">
                    Form Penjemputan
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Nama Lengkap
                      </label>
                      <input
                      required
                      type="text"
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-basmo-green focus:border-transparent outline-none transition-all"
                      placeholder="Budi Santoso" />

                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Nomor WhatsApp
                      </label>
                      <input
                      required
                      type="tel"
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-basmo-green focus:border-transparent outline-none transition-all"
                      placeholder="08123456789" />

                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">
                      Alamat Kos / Lokasi Lengkap
                    </label>
                    <textarea
                    required
                    rows={3}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-basmo-green focus:border-transparent outline-none transition-all resize-none"
                    placeholder="Jl. Pendidikan No. 12, Kos Mawar Kamar 04...">
                  </textarea>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Jenis Sampah
                      </label>
                      <select
                      required
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-basmo-green focus:border-transparent outline-none transition-all bg-white">

                        <option value="">Pilih jenis...</option>
                        <option value="botol">Botol Plastik</option>
                        <option value="galon">Galon Plastik</option>
                        <option value="campur">Campur (Botol & Galon)</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">
                        Perkiraan Jumlah
                      </label>
                      <select
                      required
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-basmo-green focus:border-transparent outline-none transition-all bg-white">

                        <option value="">Pilih jumlah...</option>
                        <option value="1-kantong">1 Kantong Besar</option>
                        <option value="2-3-kantong">2-3 Kantong Besar</option>
                        <option value="lebih-3">Lebih dari 3 Kantong</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">
                      Jadwal Penjemputan Harapan
                    </label>
                    <input
                    required
                    type="date"
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-basmo-green focus:border-transparent outline-none transition-all" />

                  </div>

                  <Button
                  type="submit"
                  variant="primary"
                  className="w-full py-4 mt-4 flex items-center justify-center gap-2 text-lg">

                    <Send className="w-5 h-5" />
                    Kirim Permintaan
                  </Button>

                  <p className="text-xs text-center text-gray-500 mt-4">
                    *Admin akan menghubungi melalui WhatsApp untuk konfirmasi
                    penjemputan.
                  </p>
                </form>
              }
            </Card>
          </motion.div>
        </div>
      </div>
    </section>);

}