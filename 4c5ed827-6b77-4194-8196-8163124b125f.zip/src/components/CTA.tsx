import React from 'react';
import { motion } from 'framer-motion';
import { Button } from './ui/Button';
export function CTA() {
  return (
    <section className="py-24 bg-gradient-to-br from-emerald-500 to-teal-600 relative overflow-hidden">
      {/* Abstract background shapes */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-white opacity-10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-full h-64 bg-gradient-to-t from-black/20 to-transparent"></div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        <motion.h2
          initial={{
            opacity: 0,
            y: 20
          }}
          whileInView={{
            opacity: 1,
            y: 0
          }}
          viewport={{
            once: true
          }}
          className="text-3xl md:text-5xl font-bold text-white mb-8 leading-tight">

          Mari bersama menciptakan lingkungan mahasiswa yang lebih bersih.
        </motion.h2>

        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          whileInView={{
            opacity: 1,
            y: 0
          }}
          viewport={{
            once: true
          }}
          transition={{
            delay: 0.2
          }}>

          <a href="#pickup-form">
            <Button
              size="lg"
              className="bg-white text-basmo-green hover:bg-gray-50 hover:text-emerald-700 shadow-xl text-lg px-10 py-5">

              Jadwalkan Penjemputan Sekarang
            </Button>
          </a>
        </motion.div>
      </div>
    </section>);

}