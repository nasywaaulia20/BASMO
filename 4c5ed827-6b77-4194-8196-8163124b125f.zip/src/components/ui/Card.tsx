import React from 'react';
import { motion } from 'framer-motion';
interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  delay?: number;
}
export function Card({
  children,
  className = '',
  delay = 0,
  ...props
}: CardProps) {
  return (
    <motion.div
      initial={{
        opacity: 0,
        y: 20
      }}
      whileInView={{
        opacity: 1,
        y: 0
      }}
      viewport={{
        once: true,
        margin: '-50px'
      }}
      transition={{
        duration: 0.5,
        delay
      }}
      className={`bg-white rounded-2xl shadow-soft border border-emerald-50 overflow-hidden ${className}`}
      {...props}>

      {children}
    </motion.div>);

}