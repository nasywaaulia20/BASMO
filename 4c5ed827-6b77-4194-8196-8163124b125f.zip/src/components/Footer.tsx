import React from 'react';
import { Leaf, Instagram, MessageCircle, Mail } from 'lucide-react';
export function Footer() {
  return (
    <footer className="bg-white pt-16 pb-8 border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 items-center mb-12">
          {/* Left: Logo */}
          <div className="flex justify-center md:justify-start">
            <a href="#" className="flex items-center gap-2 group">
              <div className="bg-basmo-green text-white p-2 rounded-xl">
                <Leaf className="w-6 h-6" />
              </div>
              <span className="font-bold text-xl tracking-tight text-basmo-dark">
                BASMO
              </span>
            </a>
          </div>

          {/* Center: Nav */}
          <nav className="flex flex-wrap justify-center gap-6 md:gap-8">
            <a
              href="#home"
              className="text-gray-600 hover:text-basmo-green font-medium transition-colors">

              Home
            </a>
            <a
              href="#problem"
              className="text-gray-600 hover:text-basmo-green font-medium transition-colors">

              Tentang
            </a>
            <a
              href="#how-it-works"
              className="text-gray-600 hover:text-basmo-green font-medium transition-colors">

              Layanan
            </a>
            <a
              href="#pickup-form"
              className="text-gray-600 hover:text-basmo-green font-medium transition-colors">

              Kontak
            </a>
          </nav>

          {/* Right: Socials */}
          <div className="flex justify-center md:justify-end gap-4">
            <a
              href="#"
              className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-gray-600 hover:bg-basmo-light hover:text-basmo-green transition-colors">

              <Instagram className="w-5 h-5" />
            </a>
            <a
              href="#"
              className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-gray-600 hover:bg-basmo-light hover:text-basmo-green transition-colors">

              <MessageCircle className="w-5 h-5" />
            </a>
            <a
              href="#"
              className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-gray-600 hover:bg-basmo-light hover:text-basmo-green transition-colors">

              <Mail className="w-5 h-5" />
            </a>
          </div>
        </div>

        <div className="text-center border-t border-gray-100 pt-8">
          <p className="text-sm text-gray-500">
            © 2026 BASMO – Bank Sampah Mobile. Mendukung gaya hidup mahasiswa
            yang ramah lingkungan.
          </p>
        </div>
      </div>
    </footer>);

}