import React from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, Trash2, Clock } from 'lucide-react';
export function Problem() {
  return (
    <section id="problem" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Visual */}
          <motion.div
            initial={{
              opacity: 0,
              scale: 0.9
            }}
            whileInView={{
              opacity: 1,
              scale: 1
            }}
            viewport={{
              once: true
            }}
            transition={{
              duration: 0.5
            }}
            className="order-2 lg:order-1 relative">

            <div className="aspect-square max-w-md mx-auto relative">
              <div className="absolute inset-0 bg-basmo-pink/20 rounded-[3rem] rotate-6"></div>
              <div className="absolute inset-0 bg-gray-50 rounded-[3rem] -rotate-3 border border-gray-100 shadow-sm flex items-center justify-center p-8">
                <div className="grid grid-cols-2 gap-4 w-full h-full relative">
                  {/* Abstract representation of piled up bottles */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-10">
                    <Trash2 className="w-64 h-64 text-gray-900" />
                  </div>

                  <div className="bg-white rounded-2xl shadow-sm p-4 flex flex-col items-center justify-center gap-2 z-10 transform translate-y-4">
                    <div className="w-8 h-16 border-2 border-gray-300 rounded-full bg-gray-50"></div>
                    <div className="w-8 h-16 border-2 border-gray-300 rounded-full bg-gray-50"></div>
                  </div>
                  <div className="bg-white rounded-2xl shadow-sm p-4 flex flex-col items-center justify-center gap-2 z-10 transform -translate-y-4">
                    <div className="w-10 h-14 border-2 border-blue-200 rounded-lg bg-blue-50"></div>
                    <div className="w-8 h-16 border-2 border-gray-300 rounded-full bg-gray-50 rotate-12"></div>
                  </div>
                  <div className="col-span-2 bg-white rounded-2xl shadow-sm p-4 flex items-center justify-center gap-4 z-10">
                    <Clock className="w-8 h-8 text-red-400" />
                    <span className="font-medium text-gray-600">
                      Tidak ada waktu
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Content */}
          <div className="order-1 lg:order-2">
            <motion.div
              initial={{
                opacity: 0,
                y: 20
              }}
              whileInView={{
                opacity: 1,
                y: 0
              }}
              viewport={{
                once: true
              }}
              transition={{
                duration: 0.5
              }}>

              <div className="inline-flex items-center gap-2 text-red-500 font-medium mb-4">
                <AlertCircle className="w-5 h-5" />
                <span>Permasalahan yang Terjadi</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6 leading-tight">
                Kamar Kos Penuh dengan Tumpukan Botol Plastik?
              </h2>
              <p className="text-lg text-gray-600 leading-relaxed mb-6">
                Banyak mahasiswa menumpuk botol plastik atau galon plastik di
                kos karena sibuk dengan tugas kuliah, malas keluar, atau tidak
                memiliki waktu untuk datang langsung ke bank sampah.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Akibatnya, sampah plastik berakhir di tempat sampah biasa dan
                tidak didaur ulang, mencemari lingkungan dan menyia-nyiakan
                potensi daur ulang.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </section>);

}