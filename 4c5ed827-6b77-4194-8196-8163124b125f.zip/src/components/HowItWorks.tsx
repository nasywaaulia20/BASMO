import React from 'react';
import { motion } from 'framer-motion';
import { FileText, CalendarCheck, Recycle } from 'lucide-react';
export function HowItWorks() {
  const steps = [
  {
    num: '1',
    icon: <FileText className="w-6 h-6 text-white" />,
    title: 'Ajukan Permintaan',
    description:
    'Mahasiswa mengisi form penjemputan sampah di website dengan detail lokasi dan jenis sampah.'
  },
  {
    num: '2',
    icon: <CalendarCheck className="w-6 h-6 text-white" />,
    title: 'Penjadwalan Penjemputan',
    description:
    'Admin BASMO mengatur jadwal pengambilan sampah dan mengkonfirmasi via WhatsApp.'
  },
  {
    num: '3',
    icon: <Recycle className="w-6 h-6 text-white" />,
    title: 'Proses Daur Ulang',
    description:
    'Sampah plastik dikumpulkan dan dikirim ke mitra daur ulang untuk diproses lebih lanjut.'
  }];

  return (
    <section id="how-it-works" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{
              opacity: 0,
              y: 20
            }}
            whileInView={{
              opacity: 1,
              y: 0
            }}
            viewport={{
              once: true
            }}
            className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">

            Cara Kerja BASMO
          </motion.h2>
          <motion.p
            initial={{
              opacity: 0,
              y: 20
            }}
            whileInView={{
              opacity: 1,
              y: 0
            }}
            viewport={{
              once: true
            }}
            transition={{
              delay: 0.1
            }}
            className="text-lg text-gray-600">

            3 langkah sederhana untuk mulai mendaur ulang
          </motion.p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* Connecting Line for Desktop */}
          <div className="hidden md:block absolute top-1/2 left-0 w-full h-1 bg-gray-100 -translate-y-1/2 z-0"></div>

          <div className="grid md:grid-cols-3 gap-12 relative z-10">
            {steps.map((step, index) =>
            <motion.div
              key={index}
              initial={{
                opacity: 0,
                y: 20
              }}
              whileInView={{
                opacity: 1,
                y: 0
              }}
              viewport={{
                once: true
              }}
              transition={{
                delay: index * 0.2
              }}
              className="flex flex-col items-center text-center relative">

                <div className="w-16 h-16 rounded-full bg-basmo-green flex items-center justify-center shadow-lg mb-6 relative">
                  {step.icon}
                  <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-basmo-pink text-pink-700 text-xs font-bold flex items-center justify-center border-2 border-white">
                    {step.num}
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {step.title}
                </h3>
                <p className="text-gray-600">{step.description}</p>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </section>);

}