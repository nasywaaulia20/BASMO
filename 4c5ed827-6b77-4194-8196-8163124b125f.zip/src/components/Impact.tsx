import React from 'react';
import { motion } from 'framer-motion';
import { Users, Truck } from 'lucide-react';
export function Impact() {
  const stats = [
  {
    icon: <div className="w-10 h-10 text-basmo-green mb-4" />,
    value: '5,200+',
    label: 'Botol Plastik Terkumpul'
  },
  {
    icon: <Users className="w-10 h-10 text-basmo-green mb-4" />,
    value: '350+',
    label: 'Mahasiswa Pengguna'
  },
  {
    icon: <Truck className="w-10 h-10 text-basmo-green mb-4" />,
    value: '840+',
    label: 'Total Penjemputan'
  }];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{
              opacity: 0,
              y: 20
            }}
            whileInView={{
              opacity: 1,
              y: 0
            }}
            viewport={{
              once: true
            }}
            className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">

            Dampak Lingkungan
          </motion.h2>
          <motion.p
            initial={{
              opacity: 0,
              y: 20
            }}
            whileInView={{
              opacity: 1,
              y: 0
            }}
            viewport={{
              once: true
            }}
            transition={{
              delay: 0.1
            }}
            className="text-lg text-gray-600">

            Bersama-sama kita membuat perubahan nyata untuk lingkungan.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat, index) =>
          <motion.div
            key={index}
            initial={{
              opacity: 0,
              scale: 0.9
            }}
            whileInView={{
              opacity: 1,
              scale: 1
            }}
            viewport={{
              once: true
            }}
            transition={{
              delay: index * 0.1
            }}
            className="flex flex-col items-center justify-center p-8 rounded-3xl bg-basmo-light/30 border border-emerald-50">

              {stat.icon}
              <h3 className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">
                {stat.value}
              </h3>
              <p className="text-gray-600 font-medium">{stat.label}</p>
            </motion.div>
          )}
        </div>
      </div>
    </section>);

}