
/** @type {import('tailwindcss').Config} */
export default {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      colors: {
        basmo: {
          green: '#059669', // emerald-600
          light: '#d1fae5', // emerald-100
          pink: '#fce7f3',  // pink-100
          dark: '#064e3b',  // emerald-900
        }
      },
      boxShadow: {
        'soft': '0 10px 40px -10px rgba(5, 150, 105, 0.1)',
      }
    },
  },
  plugins: [],
}
